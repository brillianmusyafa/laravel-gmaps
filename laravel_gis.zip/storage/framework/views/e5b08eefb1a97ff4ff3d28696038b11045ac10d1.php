<?php $__env->startSection('content'); ?>
<style type="text/css">
.no-padding {
	padding: 0px; 
}
</style>
<div class="row">
	<div class="col-md-3">
		<div class="panel panel-primary">
			<div class="panel-heading">Filter</div>
			<div class="panel-body">
				<form action="" method="GET" role="form" class="form-inline">
					<div class="form-group">
						<?php echo Form::select('kategori_id',$kat,null,['class'=>'form-control input-sm','placeholder'=>'-Pilih kategori']); ?>

						<button type="submit" class="btn btn-sm btn-danger">Submit</button>
					</div>
				</form>
			</div>
		</div>
		<div class="panel panel-primary">
			<div class="panel-heading">
				<h3 class="panel-title">Data</h3>
			</div>
			<table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Data</th>
                            <th>Jum</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $jml=0; ?>
                        <?php $__currentLoopData = $kategoryCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($cc->name); ?></td>
                            <td><?php echo e($cc->jml); ?></td>
                        </tr>
                        <?php $jml+=$cc->jml; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><strong>Total</strong></td>
                            <td><strong><?php echo e($jml); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
		</div>
	</div>
	<div class="col-md-9">
		<div class="panel panel-primary">
			<div class="panel-heading">Maps</div>

			<div class="panel-body no-padding">
				<div id="map"></div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
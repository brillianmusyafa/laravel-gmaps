<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
    <div class="panel-heading">Konfirgurasi Aplikasi</div>
    <div class="panel-body">
        <!-- <form action="" class="form-horizontal" method="POST" role="form"> -->
            <?php echo Form::open(['method'=>'POST','class'=>'form-horizontal']); ?>

            <?php $__currentLoopData = $setting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group <?php echo e($errors->has('setting_value') ? 'has-error' : ''); ?>">
                <?php echo Form::label('setting_value', $item->setting_name, ['class' => 'col-md-4 control-label']); ?>

                <div class="col-md-6">
                    <?php echo Form::text($item->setting_name, $item->setting_value, ['class' => 'form-control']); ?>

                    <?php echo $errors->first('setting_value', '<p class="help-block">:message</p>'); ?>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <button type="submit" class="btn btn-primary">Submit</button>
        <?php echo Form::close(); ?>



        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
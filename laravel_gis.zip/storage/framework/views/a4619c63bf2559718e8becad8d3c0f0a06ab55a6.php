<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Aplikasi Marker</title>
    <script src="http://maps.google.com/maps/api/js?key=<?php echo e($gmaps_api_key); ?>"></script>
    <script src="js/gmaps.js"></script>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <style type="text/css">
    #map {
      width: 100%;
      height: 500px;
  }
  .cari{
    position: absolute;
    z-index: 1000;
    top: 53px;
    left: 200px;
}

/* Small devices (tablets, 768px and up) */
@media (max-width: 360px) {
    .cari{
     position: absolute;
     z-index: 1000;
     top: 120px;
     left: 26px;
 }
}
</style>
</head>
<body>
    <nav class="navbar navbar-inverse navbar-static-top">
        <div class="container">
            <div class="navbar-header">
                <!-- Collapsed Hamburger -->
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <!-- Branding Image -->
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    <?php echo e($app_name); ?>

                </a>
            </div>

            <div class="collapse navbar-collapse" id="app-navbar-collapse">
                <!-- Left Side Of Navbar -->
                <ul class="nav navbar-nav">
                    &nbsp;
                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->
                    <?php if(Auth::guest()): ?>
                    <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                    <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                    <?php else: ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                            <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                        </a>

                        <ul class="dropdown-menu" role="menu">
                            <li>
                                <a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                                Logout
                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo e(csrf_field()); ?>

                            </form>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<div class="container-fluid">
            <?php echo $__env->yieldContent('content'); ?>

</div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script>
    var map = new GMaps({
      el: '#map',
      zoom: <?php echo e($set_zoom); ?>,
      lat: <?php echo e($latitude_centre); ?>,
      lng: <?php echo e($longitude_centre); ?>

  });

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    map.addMarker({
        lat: '<?php echo e($d->lat); ?>',
        lng: '<?php echo e($d->long); ?>',
        title: '<?php echo e($d->title); ?> #',
        icon: 'img/<?php echo e($d->Kategori->icon); ?>',
        infoWindow: {
            content : '<h3><?php echo e($d->title); ?></h3><p><?php echo e($d->description); ?></p><p><?php echo e($d->no_telp); ?></p>'
        }
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</script>

<?php echo $__env->yieldPushContent('js'); ?>
</body>
</html>
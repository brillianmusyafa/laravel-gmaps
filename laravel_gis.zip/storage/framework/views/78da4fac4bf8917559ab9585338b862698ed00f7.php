<?php $__env->startSection('content'); ?>
<style type="text/css">
.no-padding {
 padding: 0px; 
}
</style>
<div class="row">
    <div class="col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Chart Marker</h3>
            </div>
            <div class="panel-body">
                    <canvas id="myChart" width="400" height="200"></canvas>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">Summary Category</h3>
            </div>
            <div class="panel-body">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Count</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $jml=0; ?>
                        <?php $__currentLoopData = $kategoryCount; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <td><?php echo e($cc->name); ?></td>
                            <td><?php echo e($cc->jml); ?></td>
                        </tr>
                        <?php $jml+=$cc->jml; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><strong>Total</strong></td>
                            <td><strong><?php echo e($jml); ?></strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="panel panel-primary">
    <div class="panel-heading">Maps</div>

    <div class="panel-body no-padding">
       <div id="map"></div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    var map = new GMaps({
      el: '#map',
      zoom: 10,
      lat: -7.5812427,
      lng: 111.9081293
      // tegal
      // lat: -6.9764638,
      // lng: 109.1116156
  });

    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    map.addMarker({
        lat: '<?php echo e($d->lat); ?>',
        lng: '<?php echo e($d->long); ?>',
        title: '<?php echo e($d->title); ?> #',
        icon: 'img/<?php echo e($d->Kategori->icon); ?>',
        infoWindow: {
            content : '<h3><?php echo e($d->title); ?></h3><p><?php echo e($d->description); ?></p><p><?php echo e($d->no_telp); ?></p>'
        }
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.min.js"></script>
<script type="text/javascript">
    var ctx = document.getElementById("myChart").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?php echo $grafik['labels']; ?>,
        datasets: [{
            label: '# of Kategori',
            data: <?php echo e($grafik['data']); ?>,
            backgroundColor: <?php echo $grafik['backgroundColor']; ?>,
            borderColor: <?php echo $grafik['backgroundColor']; ?>,
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.adminlte', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('header'); ?>
<?php echo e($header); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('header_description'); ?>
<?php echo e($header_description); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
    <div class="panel-heading">Kategory</div>
    <div class="panel-body">

        <a href="<?php echo e(url('/kategory/create')); ?>" class="btn btn-primary btn-xs" title="Add New Kategory"><span class="glyphicon glyphicon-plus" aria-hidden="true"/></a>
        <br/>
        <br/>
        <div class="table-responsive">
            <table class="table table-borderless">
                <thead>
                    <tr>
                        <th>ID</th><th> Name </th><th> Icon </th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $kategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->name); ?></td><td><img src="img/<?php echo e($item->icon); ?>"></td>
                        <td>
                            <a href="<?php echo e(url('/kategory/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs" title="Edit Kategory"><span class="glyphicon glyphicon-pencil" aria-hidden="true"/></a>
                            <?php echo Form::open([
                                'method'=>'DELETE',
                                'url' => ['/kategory', $item->id],
                                'style' => 'display:inline'
                                ]); ?>

                                <?php echo Form::button('<span class="glyphicon glyphicon-trash" aria-hidden="true" title="Delete Kategory" />', array(
                                'type' => 'submit',
                                'class' => 'btn btn-danger btn-xs',
                                'title' => 'Delete Kategory',
                                'onclick'=>'return confirm("Confirm delete?")'
                                )); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="pagination-wrapper"> <?php echo $kategory->render(); ?> </div>
            </div>

        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
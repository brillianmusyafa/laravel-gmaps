<div class="form-group <?php echo e($errors->has('nama_aplikasi') ? 'has-error' : ''); ?>">
    <?php echo Form::label('nama_aplikasi', 'Nama Aplikasi', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('nama_aplikasi', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('nama_aplikasi', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('deskripsi') ? 'has-error' : ''); ?>">
    <?php echo Form::label('deskripsi', 'Deskripsi', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::textarea('deskripsi', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('deskripsi', '<p class="help-block">:message</p>'); ?>

    </div>
</div>


<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
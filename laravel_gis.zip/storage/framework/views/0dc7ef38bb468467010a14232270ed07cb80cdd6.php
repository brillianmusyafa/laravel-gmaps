<div class="form-group <?php echo e($errors->has('video_titl') ? 'has-error' : ''); ?>">
    <?php echo Form::label('video_titl', 'Video Titl', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('video_title', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('video_title', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('video_url') ? 'has-error' : ''); ?>">
    <?php echo Form::label('video_url', 'Video Url', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::textarea('video_url', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('video_url', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('video_id') ? 'has-error' : ''); ?>">
    <?php echo Form::label('video_id', 'Video Id', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('video_id', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('video_id', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('video_thumbnail') ? 'has-error' : ''); ?>">
    <?php echo Form::label('video_thumbnail', 'Video Thumbnail', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('video_thumbnail', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('video_thumbnail', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('video_duration') ? 'has-error' : ''); ?>">
    <?php echo Form::label('video_duration', 'Video Duration', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('video_duration', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('video_duration', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('video_description') ? 'has-error' : ''); ?>">
    <?php echo Form::label('video_description', 'Video Description', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('video_description', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('video_description', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('video_type') ? 'has-error' : ''); ?>">
    <?php echo Form::label('video_type', 'Video Type', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('video_type', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('video_type', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('size') ? 'has-error' : ''); ?>">
    <?php echo Form::label('size', 'Size', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('size', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('size', '<p class="help-block">:message</p>'); ?>

    </div>
</div>


<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>
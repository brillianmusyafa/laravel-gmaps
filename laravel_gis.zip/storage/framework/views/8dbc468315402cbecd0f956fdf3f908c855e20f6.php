<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
    <div class="panel-heading">Video</div>
    <div class="panel-body">

        <a href="<?php echo e(url('/video/create')); ?>" class="btn btn-primary btn-xs" title="Add New Video"><span class="glyphicon glyphicon-plus" aria-hidden="true"/></a>
        <br/>
        <br/>
        <div class="table-responsive">
            <table class="table table-borderless">
                <thead>
                    <tr>
                        <th>ID</th><th> Video Titl </th><th> Video Url </th><th> Video Id </th><th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->id); ?></td>
                        <td><?php echo e($item->video_title); ?></td><td><?php echo e($item->video_url); ?></td><td><?php echo e($item->video_id); ?></td>
                        <td>
                            <a href="<?php echo e(url('/video/' . $item->id)); ?>" class="btn btn-success btn-xs" title="View Video"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"/></a>
                            <a href="<?php echo e(url('/video/' . $item->id . '/edit')); ?>" class="btn btn-primary btn-xs" title="Edit Video"><span class="glyphicon glyphicon-pencil" aria-hidden="true"/></a>
                            <?php echo Form::open([
                                'method'=>'DELETE',
                                'url' => ['/video', $item->id],
                                'style' => 'display:inline'
                                ]); ?>

                                <?php echo Form::button('<span class="glyphicon glyphicon-trash" aria-hidden="true" title="Delete Video" />', array(
                                'type' => 'submit',
                                'class' => 'btn btn-danger btn-xs',
                                'title' => 'Delete Video',
                                'onclick'=>'return confirm("Confirm delete?")'
                                )); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="pagination-wrapper"> <?php echo $video->render(); ?> </div>
            </div>

        </div>
    </div>
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminlte', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
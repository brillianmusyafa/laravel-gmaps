<div class="row">
    <div class="col-md-6">
        <div class="form-group <?php echo e($errors->has('kategory_id') ? 'has-error' : ''); ?>">
            <?php echo Form::label('kategory_id', 'Kategory Id', ['class' => 'col-md-4 control-label']); ?>

            <div class="col-md-6">
                <?php echo Form::select('kategory_id',$kat, null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('kategory_id', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
            <?php echo Form::label('title', 'Title', ['class' => 'col-md-4 control-label']); ?>

            <div class="col-md-6">
                <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

                <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
            <?php echo Form::label('description', 'Description', ['class' => 'col-md-4 control-label']); ?>

            <div class="col-md-6">
                <?php echo Form::textarea('description', null, ['class' => 'form-control','rows'=>'2']); ?>

                <?php echo $errors->first('description', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>

        <div class="form-group <?php echo e($errors->has('lat') ? 'has-error' : ''); ?>">
            <?php echo Form::label('lat', 'Lat', ['class' => 'col-md-4 control-label']); ?>

            <div class="col-md-6">
                <?php echo Form::text('lat', null, ['class' => 'form-control','id'=>'lat']); ?>

                <?php echo $errors->first('lat', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
        <div class="form-group <?php echo e($errors->has('long') ? 'has-error' : ''); ?>">
            <?php echo Form::label('long', 'Long', ['class' => 'col-md-4 control-label']); ?>

            <div class="col-md-6">
                <?php echo Form::text('long', null, ['class' => 'form-control','id'=>'long']); ?>

                <?php echo $errors->first('long', '<p class="help-block">:message</p>'); ?>

            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div id="map"></div>
    </div>
</div>

<!-- <div class="form-group <?php echo e($errors->has('upload') ? 'has-error' : ''); ?>">
    <?php echo Form::label('upload', 'Upload', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::textarea('upload', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('upload', '<p class="help-block">:message</p>'); ?>

    </div>
</div> -->


<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <a class="btn btn-default" href="<?php echo e(url('maps')); ?>" role="button">Back</a>
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>


<?php $__env->startPush('js'); ?>
<script>
    var map = new GMaps({
      el: '#map',
      zoom: 10,
      lat: -7.5812427,
      lng: 111.9081293,
      click: function(e) {
        // alert('click');
        var latLng = e.latLng;
        console.log(latLng);
        var lat = $('#lat');
        var long = $('#long');

        lat.val(latLng.lat());
        long.val(latLng.lng());
        map.removeMarkers();
        map.addMarker({
            lat: latLng.lat(),
            lng: latLng.lng(),
            title: 'Create Here',
            click: function(e) {
                alert('You clicked in this marker');
            }
        });

    },
});
</script>
<?php $__env->stopPush(); ?>
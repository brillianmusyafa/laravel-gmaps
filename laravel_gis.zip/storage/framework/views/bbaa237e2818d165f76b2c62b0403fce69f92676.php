<div class="form-group <?php echo e($errors->has('setting_name') ? 'has-error' : ''); ?>">
    <?php echo Form::label('setting_name', 'Setting Name', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('setting_name', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('setting_name', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('setting_value') ? 'has-error' : ''); ?>">
    <?php echo Form::label('setting_value', 'Setting Value', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('setting_value', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('setting_value', '<p class="help-block">:message</p>'); ?>

    </div>
</div>


<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Create', ['class' => 'btn btn-primary']); ?>

    </div>
</div>